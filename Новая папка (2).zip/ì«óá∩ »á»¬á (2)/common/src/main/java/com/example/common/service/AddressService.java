package com.example.common.service;

import com.example.common.model.Address;

public interface AddressService {

    void save(Address address);
}
