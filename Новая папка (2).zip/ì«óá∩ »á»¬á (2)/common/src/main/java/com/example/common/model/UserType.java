package com.example.common.model;

public enum UserType {
    ADMIN,USER
}
